# Validation record — 2026-09-16

This record separates current local checks from the real Android capture evidence. It does not claim real macOS or M4 acceptance.

## Current local checks

- `test_facebook_cancel_transport.py`: 7 tests passed. Coverage includes process stop proof before transport cleanup, concurrent cleanup coalescing, external proxy preservation, cleanup failure lease blocking, normal completion lease release, and non-Windows behavior.
- `test_ui_v2_and_safety.WebV2IntegrationTests test_ui_v2_and_safety.WebV2BatchSelectionTests test_ui_v2_and_safety.WindowsOneClickRuntimeContractTests`: 18 tests passed. The historical source-hash class is intentionally excluded because its baseline describes an older snapshot.
- Existing stabilization regressions: 302 API/orchestration/navigation/health/client/file-sharing tests passed; 93 environment/platform/batch tests passed with 2 platform skips. These counts are recorded from the current stabilization run and should be refreshed after any further code change.
- `evidence/real-tests-20260916/inspect_batch.py batch_b6fb03dc8bc142ce --require-complete` passed against the local API. It verified three terminal, target-matched jobs and 683 aggregate CSV rows (27 + 231 + 425), with one source post ID per job and no rate-limit/auth records.

## Real Android evidence retained locally

The complete retry batch `batch_b6fb03dc8bc142ce` remains the current multi-type capture evidence. It covers a group permalink, a `share/p` URL, and a normal `pfbid` post. A low-volume Reel also completed after standby recovery. The captured artifacts and manifests remain under `runs/` and are excluded from source delivery.

## Required before publication

Run the controlled cancellation script only while the API health endpoint reports an idle worker, zero queued/cancelling jobs, and an available capture lease. The acceptance requires `cancelling -> cancelled`, stopped process identity, `transport_cleanup_state=restored`, the configured normal proxy read back on Android, a released lease, and a subsequent complete low-volume job. The script is `evidence/real-tests-20260916/cancel_acceptance.py`; it must not be treated as passed until its output is freshly recorded.

After any final source change, rerun the affected local suites, parser checks, and `git diff --check` before creating a release archive. Publish only the explicit `release-files.txt` set; never include local credentials, APKs, certificates, cookies, runs, or emulator disks.

## Stabilization closeout observations — 2026-09-16

- A fresh API restart used the project interpreter and preserved the existing emulator PID. `test_facebook_cancel_transport` plus `test_facebook_capture_api` passed 143 tests after the cancellation changes.
- `evidence/real-tests-20260916/lifecycle-20260916-130029.json` records a real `running -> cancelling -> cancelled` transition. The owned PowerShell/mitmdump/python process tree stopped, port 8081 was released, the configured Android proxy was restored, the emulator identity was preserved, and a same-worker follow-up completed with one attempt and no failover (2 CSV rows, terminal scope).
- `evidence/real-tests-20260916/failure-recovery-20260916-133410.json` records a strict URL/post-id mismatch failing with `query-not-triggered`, followed by a successful same-worker Reel task. The worker and lease returned to idle/available.
- The final five URL batch `batch_b27bda2739cc43ff` completed four cases: ordinary numeric post (234 rows), share/p (234 rows), group permalink (27 rows), and Reel (2 rows). Each had a matched target, terminal page, complete integrity, one source post ID, and one attempt on `worker-01`. The pfbid URL failed with `reaction capture is incomplete: query-not-triggered`; this is retained as a truthful partial result. The same pfbid URL has earlier terminal successful evidence in `batch_b6fb03dc8bc142ce` and `batch_34f91feb15b646e1`, so pfbid support is historically verified but not a current five-for-five claim.
- The batch inspector now checks per-job CSV user uniqueness and preserves `(job_id, user_id)` pairs across posts. Its `--require-complete` gate correctly rejected the final batch because of the pfbid failure.
