import json
import subprocess
import tempfile
import threading
import unittest
from pathlib import Path
from unittest import mock

import facebook_capture_api as api


class CancelTransportCleanupTests(unittest.TestCase):
    def _manager(self, base: Path) -> api.JobManager:
        base_patcher = mock.patch.object(api, "BASE_DIR", base)
        base_patcher.start()
        self.addCleanup(base_patcher.stop)
        thread_patcher = mock.patch("facebook_capture_api.threading.Thread.start")
        thread_patcher.start()
        self.addCleanup(thread_patcher.stop)
        self._thread_patcher = thread_patcher
        worker = api.WorkerConfig(
            "worker-02", "emulator-5556", "fb-worker-02", 18082, 18767, True
        )
        return api.JobManager(workers=[worker], worker_config_path=base / "workers.json")

    @staticmethod
    def _job(job_id: str = "fb_cancel_transport") -> dict:
        return {
            "job_id": job_id,
            "status": "running",
            "created_at": api.utc_now(),
            "started_at": api.utc_now(),
            "finished_at": None,
            "cancel_requested_at": None,
            "request": {"post_url": "https://www.facebook.com/example/posts/1", "collect": ["reactions"]},
            "result": None,
            "error": None,
            "run_dir": None,
            "worker_id": "worker-02",
            "serial": "emulator-5556",
            "process_pid": 4242,
            "process_creation_time": 123.0,
            "process_started_at": api.utc_now(),
            "process_state": "running",
            "transport_cleanup_state": "pending",
            "transport_cleanup_error": None,
        }

    def test_cleanup_runs_only_after_process_tree_stop_is_confirmed(self):
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            manager = self._manager(base)
            job = self._job()
            manager._jobs[job["job_id"]] = job
            process = mock.Mock()
            process.poll.return_value = None
            manager._running_processes[job["job_id"]] = process
            events = []

            def stop(_process):
                events.append("stop")
                return True

            def cleanup(_worker):
                events.append("cleanup")
                return {"transport_cleanup_state": "restored", "error": None}

            with mock.patch.object(api, "_terminate_tree", side_effect=stop), \
                 mock.patch.object(api, "_cleanup_transport_after_capture", side_effect=cleanup), \
                 mock.patch.object(api, "_process_identity_matches", return_value=True):
                self.assertTrue(manager._cleanup_job_process(job["job_id"]))

            self.assertEqual(events, ["stop", "cleanup"])
            self.assertEqual(job["transport_cleanup_state"], "restored")

    def test_external_proxy_change_is_reported_without_overwrite(self):
        worker = api.WorkerConfig("worker-02", "emulator-5556", "fb-worker-02", 18082, 18767, True)
        result = subprocess.CompletedProcess(
            ["powershell"],
            23,
            stdout=json.dumps({
                "transport_cleanup_state": "blocked-external-proxy",
                "current_proxy": "127.0.0.1:9999",
                "error": "Android proxy changed externally; left untouched",
            }),
            stderr="",
        )
        with mock.patch.object(api.sys, "platform", "win32"), \
             mock.patch("facebook_capture_api.shutil.which", return_value="powershell"), \
             mock.patch("facebook_capture_api._run_quiet", return_value=result) as run_quiet:
            cleanup = api._cleanup_transport_after_capture(worker)

        self.assertEqual(cleanup["transport_cleanup_state"], "blocked-external-proxy")
        self.assertEqual(cleanup["current_proxy"], "127.0.0.1:9999")
        self.assertEqual(cleanup["error"], "Android proxy changed externally; left untouched")
        run_quiet.assert_called_once()

    def test_cleanup_failure_preserves_error_and_blocks_worker(self):
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            manager = self._manager(base)
            job = self._job("fb_cleanup_failed")
            manager._jobs[job["job_id"]] = job
            process = mock.Mock()
            process.poll.return_value = None
            manager._running_processes[job["job_id"]] = process

            failure = {
                "transport_cleanup_state": "failed",
                "error": "watchdog could not be started",
            }
            with mock.patch.object(api, "_terminate_tree", return_value=True), \
                 mock.patch.object(api, "_cleanup_transport_after_capture", return_value=failure), \
                 mock.patch.object(api, "_process_identity_matches", return_value=True):
                self.assertTrue(manager._cleanup_job_process(job["job_id"]))

            self.assertEqual(job["transport_cleanup_state"], "failed")
            self.assertEqual(job["transport_cleanup_error"], "watchdog could not be started")
            self.assertTrue(manager._capture_lease_uncertain)
            self.assertIn("worker-02", manager._orphaned_worker_ids)
            self.assertEqual(job["process_state"], "stopped")

    def test_cleanup_unexpected_exception_is_persisted_and_blocks_worker(self):
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            manager = self._manager(base)
            job = self._job("fb_cleanup_exception")
            manager._jobs[job["job_id"]] = job

            with mock.patch.object(api, "_cleanup_transport_after_capture", side_effect=RuntimeError("watchdog exploded")):
                self.assertFalse(manager._cleanup_job_transport(job["job_id"]))

            self.assertEqual(job["transport_cleanup_state"], "failed")
            self.assertEqual(job["transport_cleanup_error"], "RuntimeError: watchdog exploded")
            self.assertTrue(manager._capture_lease_uncertain)
            self.assertEqual(manager._transport_cleanup_inflight, {})

    def test_concurrent_cancel_and_final_callback_run_one_cleanup(self):
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            manager = self._manager(base)
            self._thread_patcher.stop()
            job = self._job("fb_cleanup_once")
            manager._jobs[job["job_id"]] = job
            entered = threading.Event()
            release = threading.Event()
            calls = []
            results = []

            def cleanup(_worker):
                calls.append("cleanup")
                entered.set()
                self.assertTrue(release.wait(2))
                return {"transport_cleanup_state": "restored"}

            def run_cleanup():
                results.append(manager._cleanup_job_transport(job["job_id"]))

            first = threading.Thread(target=run_cleanup)
            second = threading.Thread(target=run_cleanup)
            with mock.patch.object(api.sys, "platform", "win32"), \
                 mock.patch.object(api, "_cleanup_transport_after_capture", side_effect=cleanup):
                first.start()
                self.assertTrue(entered.wait(2))
                second.start()
                release.set()
                first.join(3)
                second.join(3)

            self.assertFalse(first.is_alive())
            self.assertFalse(second.is_alive())
            self.assertEqual(calls, ["cleanup"])
            self.assertEqual(sorted(results), [True, True])
            self.assertEqual(job["transport_cleanup_state"], "restored")

    def test_normal_success_does_not_probe_transport_cleanup(self):
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            manager = self._manager(base)
            submitted = manager.submit({"post_url": "https://www.facebook.com/example/posts/1"})
            job_id = submitted["job_id"]
            manager._queue.get = mock.Mock(side_effect=[job_id, KeyboardInterrupt])
            manager._queue.task_done = mock.Mock()

            with mock.patch.object(api, "run_capture_job", return_value={"ok": True}), \
                 mock.patch.object(api, "build_api_result", return_value={"ok": True, "completion_scope": "terminal-complete"}), \
                 mock.patch.object(api, "_cleanup_transport_after_capture") as cleanup:
                with self.assertRaises(KeyboardInterrupt):
                    manager._worker_loop()

            cleanup.assert_not_called()
            self.assertEqual(manager.public_job(job_id)["status"], "completed")

    def test_failed_runner_releases_worker_for_next_job(self):
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            manager = self._manager(base)
            first = manager.submit({"post_url": "https://www.facebook.com/example/posts/1"})
            second = manager.submit({"post_url": "https://www.facebook.com/example/posts/2"})
            manager._queue.get = mock.Mock(side_effect=[first["job_id"], second["job_id"], KeyboardInterrupt])
            manager._queue.task_done = mock.Mock()

            with mock.patch.object(manager, "_worker_failure_confirmed", return_value=False), \
                 mock.patch.object(api, "run_capture_job", side_effect=[api.ApiError("ordinary runner failure"), {"ok": True}]), \
                 mock.patch.object(api, "build_api_result", return_value={"ok": True, "completion_scope": "terminal-complete"}):
                with self.assertRaises(KeyboardInterrupt):
                    manager._worker_loop()

            self.assertEqual(manager.public_job(first["job_id"])["status"], "failed")
            self.assertEqual(manager.public_job(second["job_id"])["status"], "completed")
            self.assertFalse(manager._capture_lease_uncertain)

    def test_normal_success_callback_order_releases_lease_for_next_job(self):
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            manager = self._manager(base)
            first = manager.submit({"post_url": "https://www.facebook.com/example/posts/1"})
            second = manager.submit({"post_url": "https://www.facebook.com/example/posts/2"})
            worker = manager.workers["worker-02"]
            self.assertTrue(manager._assign_job_to_worker(first["job_id"], worker))

            # Match run_capture_job's callback order: bootstrap first, then
            # the capture runner marker/process, then the runner's final
            # process callback before the worker persists success.
            bootstrap = mock.Mock()
            bootstrap.poll.return_value = 0
            capture = mock.Mock()
            capture.poll.return_value = 0
            capture.returncode = 0
            with mock.patch.object(api, "_cleanup_transport_after_capture") as cleanup:
                manager._set_running_process(first["job_id"], bootstrap)
                manager._set_running_process(first["job_id"], None)
                manager._mark_capture_runner_started(first["job_id"])
                manager._set_running_process(first["job_id"], capture)
                manager._set_running_process(first["job_id"], None)

                with manager._lock:
                    job = manager._jobs[first["job_id"]]
                    job["status"] = "completed"
                    job["finished_at"] = api.utc_now()
                    job["recovery_state"] = "completed-with-deduplicated-attempts"
                    job["transport_cleanup_state"] = api.TRANSPORT_CLEANUP_RUNNER_OWNED
                    job["transport_cleanup_error"] = None
                    manager._persist_job(job)

                manager._set_running_process(first["job_id"], None, final=True)

                self.assertEqual(manager.public_job(first["job_id"])["status"], "completed")
                self.assertFalse(manager._capture_lease_uncertain)
                manager._worker_runtime[worker.worker_id]["current_job_id"] = None
                manager._active_job_id = None
                self.assertTrue(manager._assign_job_to_worker(second["job_id"], worker))

            cleanup.assert_not_called()

    def test_no_windows_runner_keeps_cleanup_safe_without_adb_probe(self):
        worker = api.WorkerConfig("worker-02", "emulator-5556", "fb-worker-02", 18082, 18767, True)
        with mock.patch.object(api.sys, "platform", "darwin"), \
             mock.patch.object(api, "_run_quiet") as run_quiet:
            cleanup = api._cleanup_transport_after_capture(worker)

        self.assertEqual(cleanup["transport_cleanup_state"], "not-required")
        run_quiet.assert_not_called()

    def test_posix_termination_signals_session_process_group(self):
        process = mock.Mock()
        process.pid = 4244
        process.poll.side_effect = [None, 0]
        with mock.patch.object(api.os, "name", "posix"), \
             mock.patch.object(api.os, "getpgid", return_value=4244, create=True) as getpgid, \
             mock.patch.object(api.os, "killpg", create=True) as killpg, \
             mock.patch.object(api.time, "monotonic", side_effect=[0.0, 0.1]):
            self.assertTrue(api._terminate_tree(process))

        getpgid.assert_called_once_with(4244)
        killpg.assert_called_once_with(4244, api.signal.SIGTERM)
        process.terminate.assert_not_called()

    def test_macos_cleanup_requires_runner_finally_status(self):
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            manager = self._manager(base)
            job = self._job("fb_macos_cleanup")
            attempt = base / "runs" / "attempt-001"
            attempt.mkdir(parents=True)
            job["capture_run_dir"] = str(attempt)
            job["attempt_dirs"] = [str(attempt)]
            manager._jobs[job["job_id"]] = job

            with mock.patch.object(api.sys, "platform", "darwin"):
                self.assertFalse(manager._cleanup_job_transport(job["job_id"]))
            self.assertEqual(job["transport_cleanup_state"], "failed")
            self.assertIn("status is missing", job["transport_cleanup_error"])
            self.assertTrue(manager._capture_lease_uncertain)

            job["transport_cleanup_state"] = "pending"
            job["transport_cleanup_error"] = None
            job["process_pid"] = None
            job["process_creation_time"] = None
            job["process_state"] = "stopped"
            (attempt / "android-capture-status.json").write_text(
                json.dumps({"run_id": "capture-1", "exit_code": 143, "cleanup_errors": []}), encoding="utf-8"
            )
            with mock.patch.object(api.sys, "platform", "darwin"):
                self.assertTrue(manager._cleanup_job_transport(job["job_id"]))
            self.assertEqual(job["transport_cleanup_state"], api.TRANSPORT_CLEANUP_RUNNER_OWNED)
            self.assertFalse(manager._capture_lease_uncertain)

    def test_macos_cleanup_does_not_accept_older_attempt_status(self):
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            manager = self._manager(base)
            job = self._job("fb_macos_stale_cleanup")
            old_attempt = base / "runs" / "attempt-001"
            current_attempt = base / "runs" / "attempt-002"
            old_attempt.mkdir(parents=True)
            current_attempt.mkdir(parents=True)
            (old_attempt / "android-capture-status.json").write_text(
                json.dumps({"run_id": "old", "exit_code": 143, "cleanup_errors": []}), encoding="utf-8"
            )
            job["capture_run_dir"] = str(current_attempt)
            job["attempt_dirs"] = [str(old_attempt), str(current_attempt)]
            manager._jobs[job["job_id"]] = job

            with mock.patch.object(api.sys, "platform", "darwin"):
                self.assertFalse(manager._cleanup_job_transport(job["job_id"]))
            self.assertEqual(job["transport_cleanup_state"], "failed")
            self.assertIn("status is missing", job["transport_cleanup_error"])


if __name__ == "__main__":
    unittest.main()
