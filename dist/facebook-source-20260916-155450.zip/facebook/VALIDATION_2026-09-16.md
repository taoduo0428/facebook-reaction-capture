# Validation record — 2026-09-16

This record separates current local checks from the real Android capture evidence. It does not claim real macOS or M4 acceptance.

## Earlier local baseline (before final closeout)

- `test_facebook_cancel_transport.py`: 7 tests passed. Coverage includes process stop proof before transport cleanup, concurrent cleanup coalescing, external proxy preservation, cleanup failure lease blocking, normal completion lease release, and non-Windows behavior.
- `test_ui_v2_and_safety.WebV2IntegrationTests test_ui_v2_and_safety.WebV2BatchSelectionTests test_ui_v2_and_safety.WindowsOneClickRuntimeContractTests`: 18 tests passed. The historical source-hash class is intentionally excluded because its baseline describes an older snapshot.
- Earlier stabilization regressions: 302 API/orchestration/navigation/health/client/file-sharing tests passed; 93 environment/platform/batch tests passed with 2 platform skips. These are historical snapshots within this day's work, not final-source acceptance counts.
- `evidence/real-tests-20260916/inspect_batch.py batch_b6fb03dc8bc142ce --require-complete` passed against the local API. It verified three terminal, target-matched jobs and 683 aggregate CSV rows (27 + 231 + 425), with one source post ID per job and no rate-limit/auth records.

## Real Android evidence retained locally

The earlier complete retry batch `batch_b6fb03dc8bc142ce` covers a group permalink, a `share/p` URL, and a normal `pfbid` post. A low-volume Reel also completed after standby recovery. These runs are retained as historical evidence; later code must pass fresh acceptance. The captured artifacts and manifests remain under `runs/` and are excluded from source delivery.

## Required before publication

Run `evidence/real-tests-20260916/lifecycle_acceptance.py` only while the API health endpoint reports an idle worker, zero queued/cancelling jobs, and an available capture lease. Acceptance requires `cancelling -> cancelled`, stopped process identity, `transport_cleanup_state=restored`, the configured normal proxy read back on Android, a released lease, and a subsequent complete low-volume job. The first accepted run is recorded below; changes to cancellation or target verification require renewed acceptance.

After any final source change, rerun the affected local suites, parser checks, and `git diff --check` before creating a release archive. Publish only the explicit `release-files.txt` set; never include local credentials, APKs, certificates, cookies, runs, or emulator disks.

## Stabilization closeout observations — 2026-09-16

- A fresh API restart used the project interpreter and preserved the existing emulator PID. `test_facebook_cancel_transport` plus `test_facebook_capture_api` passed 143 tests after the cancellation changes.
- `evidence/real-tests-20260916/lifecycle-20260916-130029.json` records a real `running -> cancelling -> cancelled` transition. The owned PowerShell/mitmdump/python process tree stopped, port 8081 was released, the configured Android proxy was restored, the emulator identity was preserved, and a same-worker follow-up completed with one attempt and no failover (2 CSV rows, terminal scope).
- `evidence/real-tests-20260916/failure-recovery-20260916-133410.json` records a strict URL/post-id mismatch rejected with `Target post could not be confirmed after 3 strict attempts; capture aborted.`, followed by a successful same-worker Reel task (49.88 s, 2 CSV rows, one attempt, no failover). The worker and lease returned to idle/available.
- The final five URL batch `batch_b27bda2739cc43ff` completed four cases: ordinary numeric post (234 rows), share/p (234 rows), group permalink (27 rows), and Reel (2 rows). Each had a matched target, terminal page, complete integrity, one source post ID, and one attempt on `worker-01`. The pfbid URL failed with `reaction capture is incomplete: query-not-triggered`; this is retained as a truthful partial result. The same pfbid URL has earlier terminal successful evidence in `batch_b6fb03dc8bc142ce` and `batch_34f91feb15b646e1`, so pfbid support is historically verified but not a current five-for-five claim.
- The batch inspector now checks per-job CSV user uniqueness and preserves `(job_id, user_id)` pairs across posts. Its `--require-complete` gate correctly rejected the final batch because of the pfbid failure.

## Candidate source archive snapshot

- `evidence/real-tests-20260916/release-verification-20260916-140751.json` accepted the 119-file candidate archive `facebook-source-20260916-140145.zip`. A fresh extraction ran 524 tests successfully (2 skips), both JavaScript syntax checks, all manifest PowerShell parsers and `pip check`. Archive members and SHA-256 entries matched that source snapshot.
- This candidate predates later document and review fixes. It is not the final release artifact; export and verify a new archive after source and documentation are final.
- A source whitelist audit found no excluded runtime paths or Git-ignored entries. The private-key signature in `test_facebook_mac_device.py` is a deliberately incomplete marker used to test rejection, not key material.

## Open closeout items

- The pfbid failure was traced to inline Feed-card promotion recognizing only English sharing-audience labels. The recorded Chinese timestamp must be recognized while preserving strict detail and target guards, then the original URL and five-type sequence must pass again.
- Independent review identified process-stop error handling, malformed/conflicting cleanup results, incomplete macOS cleanup evidence and ambiguous target-ID/author proof. Regression fixtures and focused repairs are in progress.
- Re-run final-source checks, update this record with new live results, refresh the source archive and publish the reviewed stabilization branch. No main-branch merge or real-Mac acceptance is claimed here.
